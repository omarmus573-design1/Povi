POVI MVP

This is a zero-cost static prototype. It runs entirely in the browser and stores demo interests/posts locally.

It is NOT yet a real multi-user social network. The conversation screen is a simulation of the future interaction model.

To publish for free with GitHub Pages:
1. Create a GitHub account at github.com if you don't have one.
2. Create a new public repository named povi.
3. Upload index.html (and optionally this README.txt).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and / (root), then Save.
7. Wait for the Pages deployment. GitHub will show the live site address.

Alternative: Cloudflare Pages can deploy the same folder as a static site.

Before inviting real users, Povi needs a real backend, authentication, age/privacy controls, moderation, reporting/blocking, secure data handling, and legal/privacy review.
